//
//  Yelp APIs.swift
//  Get Restaurant
//
//  Created by Daniel Eze on 2022-10-22.
//

import Foundation
import Combine
import CoreLocation

// Yelp backend

struct YelpAPIService{
    var search: (String, CLLocationCoordinate2D) ->AnyPublisher<[Business], Never>
}

// gets the api data
extension YelpAPIService{
    static let live = YelpAPIService {term, coordinates in
        var urlComponent = URLComponents(string:"https://api.yelp.com")!
        urlComponent.path = "/v3/businesses/search"
        urlComponent.queryItems = [
            URLQueryItem(name: "term", value: term),
            URLQueryItem(name: "longitude", value: String(coordinates.longitude)),
            URLQueryItem(name: "latitude", value: String(coordinates.latitude)),
        ]
        
        let url = urlComponent.url!
        var request = URLRequest(url: url)
        request.addValue("Bearer itoMaM6DJBtqD54BHSZQY9WdWR5xI_CnpZdxa3SG5i7N0M37VK1HklDDF4ifYh8SI-P2kI_mRj5KRSF4_FhTUAkEw322L8L8RY6bF1UB8jFx3TOR0-wW6Tk0KftNXXYx", forHTTPHeaderField: "Authorization")
        
        // returns the decoded data.
        return URLSession.shared.dataTaskPublisher(for: request)
            .map(\.data)
            .decode(type: Result.self, decoder: JSONDecoder())
            .map(\.businesses)
            .replaceError(with: [])
            .receive(on: DispatchQueue.main)
            .eraseToAnyPublisher()
    }
}


