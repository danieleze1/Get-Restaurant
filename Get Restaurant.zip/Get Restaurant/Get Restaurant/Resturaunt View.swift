//
//  Resturaunt View.swift
//  Get Restaurant
//
//  Created by Daniel Eze on 2022-10-22.
//

import SwiftUI

struct Restaurant{
    var name: String
    var address: String
    var contact: String
    var isClosed: Bool?
    var imageURL: String?
}

// This creates the card like view

struct Restaurant_View: View {
    
    var restraunt: Restaurant

    var body: some View {
        ZStack(alignment:.center){
            RoundedRectangle(cornerRadius: 20)
                .frame(width: 325, height: 500)
                .foregroundColor(.pink)
                .opacity(0.5)
                .padding()

              VStack{
                // Loads the image of the restaurants
                AsyncImage(url: URL(string: restraunt.imageURL ?? "https://s3-media2.fl.yelpcdn.com/bphoto/MmgtASP3l_t4tPCL1iAsCg/o.jpg"), content: { image in
                            image.resizable()
                        }, placeholder: {
                            ProgressView()
                        })
                            .frame(width: 260, height: 260)
                            .clipShape(RoundedRectangle(cornerRadius: 10))
            
                  //Restaurant info
                VStack(alignment: .leading){
                    Text(restraunt.name)
                        .font(.title2)
                        .fontWeight(.semibold)
                        .lineLimit(2)
                        .frame(maxWidth: 265, alignment: .leading)

                    
                    Text(restraunt.address)
                        .fontWeight(.medium)
                        .padding(.top, -2.0)
                        .padding(.bottom, -2.5)
                        .lineLimit(2)
                        .frame(maxWidth: 265, alignment: .leading)

                    if restraunt.isClosed != nil{
                        Text(restraunt.isClosed! ? "Closed":"Open")
                            .foregroundColor(restraunt.isClosed! ? .red:.green)
                            .padding(.bottom, -2.5)
                    }
                    
                    if restraunt.contact != nil{
                        Text(restraunt.contact)
                    }
                }
            }
        }
    }
}

struct Restaurant_View_Previews: PreviewProvider {
    static var previews: some View {
        Restaurant_View(restraunt: Restaurant(name: "Name", address: "Address", contact: "Phone", isClosed: true))
    }
}
