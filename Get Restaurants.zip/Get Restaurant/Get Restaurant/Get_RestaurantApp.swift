//
//  Get_RestaurantApp.swift
//  Get Restaurant
//
//  Created by Daniel Eze on 2022-10-21.
//

import SwiftUI

@main
struct Get_RestaurantApp: App {
    var body: some Scene {
        WindowGroup {
            Starter_View()
        }
    }
}
