//
//  ContentView.swift
//  Get Restaurant
//
//  Created by Daniel Eze on 2022-10-21.
//

import SwiftUI
import CoreLocation

//This is the main view

struct ContentView: View {

    @ObservedObject var restaurants = Restaurants()
    @ObservedObject var location: LocationDataManager
    @State private var showLocationAlert = false
    @State private var showContentView = false

    var body: some View {
        GeometryReader{ geo in
            VStack(alignment: .center){
                    ScrollView(.horizontal){
                        LazyHStack(alignment: .center, spacing: 55){ // Lazy Hstack to save resources
                            ForEach(restaurants.businesses, id: \.id){
                                Restaurant_View(restraunt: makeRestaurant(business: $0))
                            }
                        }
                        .frame(width:.infinity)
                    }
                }
            .padding(.vertical)
        }
        .navigationBarTitleDisplayMode(.large)
        .navigationTitle("Food Time")
        .alert(isPresented: $showLocationAlert){
            // This alerts informs user that their location is needed.
            Alert (title: Text("Location needed."),
                        message: Text("Food Time needs your location to get restraunts for you. Enable Access to find nearby restaurants."),
                   primaryButton: .default(Text("Enable Access"),action: {
                UIApplication.shared.open(URL(string: UIApplication.openSettingsURLString)!)
                        }),
                        secondaryButton: .default(Text("Cancel")))
                            
        }
        .onAppear{
            //Starts the restaurant search
            restaurants.search(location: location)
            // Checks if location is enabled
            checkLocation()
        }
    }
    
    func makeRestaurant(business bus: Business) -> Restaurant{
        
        // This function helps to create a simple restaurant struct
        // Using the Business Class. I had some issues passing codable
        // classes lol.
        
        let location = bus.location
        var address = ""
        
        if (location != nil){
            address = "\(location!.address1 ?? "") \(location!.zipCode ?? "") \(location!.city ?? "")"
        }
        
        return Restaurant(name: bus.name ?? "", address: address , contact: bus.phone ?? "", isClosed: bus.isClosed, imageURL: bus.imageURL)
    }
    
    func checkLocation(){
        // This checks if location authorization is granted. If it is not, then we show alert to
        // enable it by chaging the value of the binded bool for its alert.
        
        if location.locationManager.authorizationStatus == .denied ||
            location.locationManager.authorizationStatus == .restricted{
            showLocationAlert = true
        }
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView(location: LocationDataManager())
    }
}
