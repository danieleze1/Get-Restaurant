//
//  Business Structs and Classes.swift
//  Get Restaurant
//
//  Created by Daniel Eze on 2022-10-22.
//

// Our classes and Structs.

import Foundation
import CoreLocation
import Combine

struct Result: Codable{
    var total: Int
    var businesses: [Business]
}

final class Restaurants: ObservableObject{
    @Published var businesses = [Business]()

    func search(location: LocationDataManager){
        location.update()
        
        let live = YelpAPIService.live

        live.search("restaurant", location.location ?? CLLocationCoordinate2D.init(latitude: 0, longitude: 0))
            .assign(to: &$businesses)

    }
}

// This file was generated from JSON Schema using quicktype, do not modify it directly.
// To parse the JSON, add this file to your project and do:
//
//   let business = try? newJSONDecoder().decode(Business.self, from: jsonData)

import Foundation

// MARK: - Business
struct Business: Codable {
    let rating: Double?
    let price, phone, id, alias: String?
    let isClosed: Bool?
    let categories: [Category]?
    let reviewCount: Double?
    let name: String?
    let url: String?
    let coordinates: Coordinates?
    let imageURL: String?
    let location: Location?
    let distance: Double?
    let transactions: [String]?

    enum CodingKeys: String, CodingKey {
        case rating, price, phone, id, alias
        case isClosed = "is_closed"
        case categories
        case reviewCount = "review_count"
        case name, url, coordinates
        case imageURL = "image_url"
        case location, distance, transactions
    }
}

// MARK: - Category
struct Category: Codable {
    let alias, title: String?
}

// MARK: - Coordinates
struct Coordinates: Codable {
    let latitude, longitude: Double?
}

// MARK: - Location
struct Location: Codable {
    let city, country, address2, address3: String?
    let state, address1, zipCode: String?

    enum CodingKeys: String, CodingKey {
        case city, country, address2, address3, state, address1
        case zipCode = "zip_code"
    }
}

