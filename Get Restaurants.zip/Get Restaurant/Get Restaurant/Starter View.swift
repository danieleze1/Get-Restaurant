//
//  Starter View.swift
//  Get Restaurant
//
//  Created by Daniel Eze on 2022-10-21.
//

// This is the very first view we have. It creates and instance of the locationData Manager Class. It also ativates the Yelp API.

import SwiftUI

struct Starter_View: View {
    @StateObject var location = LocationDataManager()

    var live = YelpAPIService.live
    
    var body: some View {
        
        NavigationView{
            VStack {
                Text("🍿")
                    .font(.largeTitle)
                    .fontWeight(.heavy)
                    
                Text("Food Time")
                    .font(.largeTitle)
                
                NavigationLink{
//                    Second View
                    ContentView(location: location)               
                }label: {
                    ZStack{
                        RoundedRectangle(cornerRadius: 20)
                            .frame(maxWidth: 200, maxHeight: 55)
                            .foregroundColor(.pink)
                            .opacity(0.8)
                        
                        Text("Let's go !")
                            .fontWeight(.regular)
                            .foregroundColor(.primary)
                    }
                }
            }
        }
    }
}

struct Starter_View_Previews: PreviewProvider {
    static var previews: some View {
        Starter_View()

    }
}
