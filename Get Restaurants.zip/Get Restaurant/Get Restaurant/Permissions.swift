//
//  Permissions.swift
//  Get Restaurant
//
//  Created by Daniel Eze on 2022-10-21.
//

// The location permissions.

import Foundation
import CoreLocation

class LocationDataManager : NSObject, CLLocationManagerDelegate, ObservableObject {
    var locationManager = CLLocationManager()
    @Published var location: CLLocationCoordinate2D?
    @Published var adress:CLLocation?

   override init() {
      super.init()
       locationManager.delegate = self
       locationManager.startUpdatingLocation()
   }


    func locationManagerDidChangeAuthorization(_ manager: CLLocationManager) {
        switch manager.authorizationStatus {
        case .authorizedWhenInUse:  // Location services are available.
            break
            
        case .restricted, .denied:  // Location services currently unavailable.
            manager.requestWhenInUseAuthorization()
            break
            
        case .notDetermined:        // Authorization not determined yet.
            manager.requestWhenInUseAuthorization()
            break
            
        default:
            manager.startUpdatingLocation()
            break
        }
    }
    
    func update(){
        // updates the users location
        locationManager.startUpdatingLocation()
    }
    
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]){
        // if location changes, it updates.
        location = locations.first?.coordinate
        adress = locations.first
    }
}


